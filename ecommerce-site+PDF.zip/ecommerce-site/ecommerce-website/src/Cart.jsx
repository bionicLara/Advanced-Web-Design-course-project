import React from 'react';

const Cart = ({ cartItems, removeFromCart }) => (
  <div className="container">
    <h1>Cart</h1>
    {cartItems.length === 0 ? (
      <p>No items in cart</p>
    ) : (
      cartItems.map(item => (
        <div key={item.id} className="cart-item">
          <h2>{item.name}</h2>
          <p>${item.price}</p>
          <button onClick={() => removeFromCart(item.id)}>Remove</button>
        </div>
      ))
    )}
  </div>
);

export default Cart;
