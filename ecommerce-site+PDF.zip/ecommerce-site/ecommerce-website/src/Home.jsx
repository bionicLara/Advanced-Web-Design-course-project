import React from 'react';
import Product from './Product';
import data from './products';

const Home = ({ addToCart }) => (
  <div className="container">
    <h1>Products</h1>
    {data.map(product => (
      <Product key={product.id} product={product} addToCart={addToCart} />
    ))}
  </div>
);

export default Home;
