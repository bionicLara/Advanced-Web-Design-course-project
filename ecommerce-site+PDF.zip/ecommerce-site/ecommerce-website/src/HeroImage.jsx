// HeroImage.jsx

import React from 'react';

const HeroImage = () => {
  return (
    <div className="hero-image">
      <img src="/path/to/hero-image.jpg" alt="Hero Image" />
    </div>
  );
};

export default HeroImage;
