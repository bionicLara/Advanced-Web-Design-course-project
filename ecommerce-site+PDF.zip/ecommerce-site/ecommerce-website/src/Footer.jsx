

import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <p>&copy; 2024 Ecommerce Website. All rights reserved.</p>
        <p>Email: info@example.com</p>
      </div>
    </footer>
  );
};

export default Footer;
